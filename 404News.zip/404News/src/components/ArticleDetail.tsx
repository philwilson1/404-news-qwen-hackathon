import { useState, useRef, useEffect } from 'react';
import { X, CheckCircle2, Eye, Clock, Send, Sparkles, Loader2 } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { supabase, saveChatMessage, API_URL, type Article } from '../lib/supabase';

interface DisplayMessage { id: string; role: 'user' | 'assistant'; content: string; }

export default function ArticleDetail({ article, onClose }: {
  article: Article | null;
  onClose: () => void;
}) {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<DisplayMessage[]>([]);
  const [sending, setSending] = useState(false);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Load chat history for this specific article from Supabase
  useEffect(() => {
    if (!article) return;

    let isMounted = true;

    async function loadArticleChatHistory() {
      setLoadingHistory(true);
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
          if (isMounted) {
            setMessages([
              {
                id: 'system-init',
                role: 'assistant',
                content: `Hi! I am 404 AI. I have fully indexed this article. Ask me any specific questions about it!`
              }
            ]);
            setLoadingHistory(false);
          }
          return;
        }

        const { data, error } = await supabase
          .from('chat_history')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: true });

        if (error) throw error;

        // Filter messages tied to this article
        const articleMessages = (data || []).filter((msg) => {
          if (!msg.sources || !Array.isArray(msg.sources)) return false;
          return msg.sources.some((src: any) => 
            src?.id === article?.id || 
            src?.title === article?.title || 
            src === article?.id
          );
        });

        if (isMounted) {
          if (articleMessages.length > 0) {
            setMessages(
              articleMessages.map((m, idx) => ({
                id: m.id || `hist-${idx}`,
                role: m.role as 'user' | 'assistant',
                content: m.content || ''
              }))
            );
          } else {
            setMessages([
              {
                id: 'system-init',
                role: 'assistant',
                content: `Hi! I am 404 AI. I have fully indexed this article. Ask me any specific questions about it!`
              }
            ]);
          }
        }
      } catch (err) {
        console.error('Error loading article chat history:', err);
        if (isMounted) {
          setMessages([
            {
              id: 'system-init',
              role: 'assistant',
              content: `Hi! I am 404 AI. I have fully indexed this article. Ask me any specific questions about it!`
            }
          ]);
        }
      } finally {
        if (isMounted) setLoadingHistory(false);
      }
    }

    loadArticleChatHistory();

    return () => {
      isMounted = false;
    };
  }, [article]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loadingHistory]);

  if (!article) return null;

  const handleSend = async () => {
    const query = input.trim();
    if (!query || sending) return;

    setInput('');

    const userMsg: DisplayMessage = { id: `u-${Date.now()}`, role: 'user', content: query };
    const assistantId = `a-${Date.now()}`;
    const assistantMsg: DisplayMessage = { id: assistantId, role: 'assistant', content: '' };

    setMessages((prev) => [...prev, userMsg, assistantMsg]);
    setSending(true);

    // Save user message to Supabase chat history
    try {
      await saveChatMessage('user', query, [article]);
    } catch (e) {
      console.warn('Failed to persist user message:', e);
    }

    try {
      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token;

      // Include recent messages in the request for prompt continuity
      const historyPayload = messages
        .filter((m) => m.id !== 'system-init')
        .concat(userMsg)
        .map((m) => ({ role: m.role, content: m.content }));

      const res = await fetch(`${API_URL}/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          messages: historyPayload.length > 0 ? historyPayload : [{ role: 'user', content: query }],
          articles: [{ title: article.title, summary: article.summary, source: article.source }],
          stream: true,
        }),
      });

      if (!res.ok || !res.body) throw new Error('bad response');

      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = '';
      let finalContent = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buf += dec.decode(value, { stream: true });
        const lines = buf.split('\n');
        buf = lines.pop() ?? '';

        for (const line of lines) {
          const t = line.trim();
          if (!t.startsWith('data: ')) continue;
          const p = t.slice(6);

          if (p === '[DONE]') {
            await saveChatMessage('assistant', finalContent, [article]);
            setSending(false);
            return;
          }

          try {
            const parsed = JSON.parse(p);
            const tok = parsed.choices?.[0]?.delta?.content || parsed.content || '';
            if (tok) {
              finalContent += tok;
              setMessages((prev) =>
                prev.map((m) => (m.id === assistantId ? { ...m, content: m.content + tok } : m))
              );
            }
          } catch {
            if (p) {
              finalContent += p;
              setMessages((prev) =>
                prev.map((m) => (m.id === assistantId ? { ...m, content: m.content + p } : m))
              );
            }
          }
        }
      }
      await saveChatMessage('assistant', finalContent, [article]);
      setSending(false);
    } catch (err) {
      console.error('Article chat error:', err);
      setMessages((prev) =>
        prev.map((m) => (m.id === assistantId ? { ...m, content: 'Sorry, something went wrong. Please try again.' } : m))
      );
      setSending(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/70 flex items-end sm:items-center justify-center animate-fadeIn"
      onClick={onClose}
    >
      <div
        className="bg-zinc-950 border border-zinc-800 rounded-t-2xl sm:rounded-2xl w-full sm:max-w-xl h-[90vh] flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-zinc-950 border-b border-zinc-900 px-4 py-3 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-2 text-[11px]">
            <span className="flex items-center justify-center w-5 h-5 rounded bg-zinc-800 text-zinc-400 font-bold text-[9px]">
              {article.source_logo}
            </span>
            <span className="text-zinc-400 font-medium">{article.source}</span>
          </div>
          <button onClick={onClose} className="p-1 text-zinc-500 hover:text-white transition-colors">
            <X size={20} />
          </button>
        </div>

        {/* Scrollable Content Container */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
          {article.image_url && (
            <div className="h-44 overflow-hidden rounded-xl">
              <img src={article.image_url} alt="" className="w-full h-full object-cover" />
            </div>
          )}

          <div>
            <h2 className="text-white font-bold text-xl leading-tight mb-2">{article.title}</h2>
            <div className="flex items-center gap-3 text-[11px] text-zinc-500 mb-3">
              {article.verified && (
                <span className="inline-flex items-center gap-1 text-emerald-400">
                  <CheckCircle2 size={12} />
                  <span className="font-semibold">Verified · {(article.confidence * 100).toFixed(0)}%</span>
                </span>
              )}
              <span className="inline-flex items-center gap-1"><Eye size={12} /> {article.views}</span>
              <span className="inline-flex items-center gap-1"><Clock size={12} /> {article.read_time} min read</span>
            </div>
            <div className="text-zinc-300 text-sm leading-relaxed bg-zinc-900/40 p-3 rounded-xl border border-zinc-900 prose prose-invert prose-sm max-w-none">
              <ReactMarkdown>{article.summary}</ReactMarkdown>
            </div>
          </div>

          {/* Inline Contextual Chat */}
          <div className="pt-4 border-t border-zinc-900 flex flex-col flex-1 min-h-[300px]">
            <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-2">
              Context-Aware Discussion Panel
            </p>

            {loadingHistory ? (
              <div className="flex items-center justify-center py-8 text-zinc-500 gap-2 text-xs">
                <Loader2 size={14} className="animate-spin" />
                <span>Restoring past discussion...</span>
              </div>
            ) : (
              <div className="flex-1 space-y-3 mb-4">
                {messages.map((msg) => (
  <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
    <div className={`max-w-[90%] rounded-xl px-3 py-2 text-xs ${msg.role === 'user' ? 'bg-sky-500 text-white' : 'bg-zinc-900 border border-zinc-800 text-zinc-200'}`}>
      {msg.role === 'assistant' && (
        <div className="flex items-center gap-1.5 mb-1 text-sky-400 font-semibold">
          <Sparkles size={10} /> <span>404 AI</span>
        </div>
      )}
      
      {msg.role === 'assistant' && !msg.content ? (
        <div className="flex items-center gap-2 text-zinc-400 text-xs py-1 italic">
          <span className="flex gap-1 items-center">
            <span className="w-1.5 h-1.5 bg-sky-400 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
            <span className="w-1.5 h-1.5 bg-sky-400 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
            <span className="w-1.5 h-1.5 bg-sky-400 rounded-full animate-bounce"></span>
          </span>
          <span className="text-[11px] text-zinc-500 font-mono">Analyzing article & drafting reply...</span>
        </div>
      ) : (
        <div className="leading-relaxed prose prose-invert prose-xs max-w-none">
          <ReactMarkdown>{msg.content}</ReactMarkdown>
        </div>
      )}
    </div>
  </div>
))}
                <div ref={chatEndRef} />
              </div>
            )}
          </div>
        </div>

        {/* Fixed Input Box at Bottom of Modal */}
        <div className="p-3 border-t border-zinc-900 bg-zinc-950 flex-shrink-0">
          <div className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 rounded-xl p-1.5">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask about this story..."
              disabled={sending || loadingHistory}
              className="flex-1 bg-transparent text-white text-xs placeholder:text-zinc-600 outline-none px-2"
            />
            <button
              onClick={handleSend}
              disabled={sending || loadingHistory || !input.trim()}
              className="w-8 h-8 rounded-lg bg-sky-500 flex items-center justify-center text-white transition-transform disabled:opacity-40"
            >
              <Send size={12} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}