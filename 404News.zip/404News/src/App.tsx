import { useState, useCallback, useEffect } from 'react';
import Header from './components/Header';
import BottomNav, { type Tab } from './components/BottomNav';
import SideDrawer from './components/SideDrawer';
import FeedView from './components/FeedView';
import AIView from './components/AIView';
import TopicsView from './components/TopicsView';
import ProfileView from './components/ProfileView';
import BookmarksView from './components/BookmarksView';
import SearchView from './components/SearchView'; // 1. Import SearchView
import Toast, { type ToastState } from './components/Toast';
import AuthView from './components/AuthView';
import { getCurrentUser, onAuthChange, type AuthUser } from './lib/supabase';

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('feed');
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [toast, setToast] = useState<ToastState | null>(null);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [showBookmarks, setShowBookmarks] = useState(false);
  const [showSearch, setShowSearch] = useState(false); // 2. Add showSearch state
  
  // Category state (defaults to 'tech')
  const [activeCategory, setActiveCategory] = useState<string>('tech');

  useEffect(() => {
    getCurrentUser().then((u) => {
      setUser(u);
      setAuthLoading(false);
    });
    const unsubscribe = onAuthChange((u) => setUser(u));
    return unsubscribe;
  }, []);

  const showLockedToast = useCallback(() => {
    setToast({
      id: Date.now(),
      title: 'Under Construction by the Agents',
      message: 'Our AI team is currently optimizing the data pipelines for this category. Stay tuned — greatness takes a little time.',
    });
  }, []);

  const dismissToast = useCallback(() => setToast(null), []);

  const handleSelectCategory = useCallback((category: string) => {
    setActiveCategory(category);
    setActiveTab('feed'); // Ensure user jumps back to the main feed tab when switching categories
    setShowBookmarks(false);
    setShowSearch(false); // Close search view if a category is selected from the drawer
  }, []);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-zinc-950 flex items-center justify-center">
        <div className="w-10 h-10 border-2 border-zinc-700 border-t-sky-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <AuthView />;
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="mx-auto max-w-md min-h-screen bg-zinc-950 relative shadow-2xl">
        {/* 3. Connect onSearchClick to trigger showSearch */}
        <Header 
          onOpenDrawer={() => setDrawerOpen(true)} 
          onSearchClick={() => {
            setShowSearch(true);
            setShowBookmarks(false);
          }} 
        />
        
        <main>
          {/* 4. Prioritize rendering SearchView when active */}
          {showSearch ? (
            <SearchView onBack={() => setShowSearch(false)} />
          ) : showBookmarks ? (
            <BookmarksView onBack={() => setShowBookmarks(false)} />
          ) : (
            <>
              {activeTab === 'feed' && <FeedView category={activeCategory} />}
              {activeTab === 'following' && <TopicsView />}
              {activeTab === 'ai' && <AIView />}
              {activeTab === 'profile' && (
                <ProfileView user={user} onOpenBookmarks={() => setShowBookmarks(true)} />
              )}
            </>
          )}
        </main>

        <BottomNav 
          active={activeTab} 
          onChange={(tab) => {
            setActiveTab(tab);
            setShowSearch(false); // Close search when switching bottom tabs
            setShowBookmarks(false);
          }} 
        />
      </div>

      <SideDrawer 
        open={drawerOpen} 
        onClose={() => setDrawerOpen(false)} 
        onLockedCategory={showLockedToast}
        activeCategory={activeCategory}
        onSelectCategory={handleSelectCategory}
      />
      
      <Toast toast={toast} onDismiss={dismissToast} />
    </div>
  );
}

export default App;